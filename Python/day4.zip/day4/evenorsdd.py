num=int(input("Enter the number: "))
if num%2==0:
    print("The ",num, "is even")
else:
    print("The", num ,"is odd")